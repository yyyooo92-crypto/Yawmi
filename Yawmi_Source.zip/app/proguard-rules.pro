-keepclassmembers class com.yawmi.app.AndroidBridge {
    @android.webkit.JavascriptInterface <methods>;
}
