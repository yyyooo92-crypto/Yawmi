package com.yawmi.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class SnoozeReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        String taskJson = intent.getStringExtra("task_json");
        if (taskJson == null || taskJson.isEmpty()) return;
        AlarmScheduler.scheduleSnooze(context, taskJson, System.currentTimeMillis() + 5 * 60_000L);
    }
}
