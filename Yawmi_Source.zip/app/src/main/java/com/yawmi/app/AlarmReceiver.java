package com.yawmi.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        String taskJson = intent.getStringExtra("task_json");
        if (taskJson == null || taskJson.isEmpty()) return;
        boolean snooze = intent.getBooleanExtra("is_snooze", false);
        AlarmScheduler.createNotificationChannels(context);
        NotificationHelper.showTaskNotification(context, taskJson, snooze);
        if (!snooze) {
            AlarmScheduler.scheduleAll(context, System.currentTimeMillis() + 1_000L);
        }
    }
}
