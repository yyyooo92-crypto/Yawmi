package com.yawmi.app;

import android.app.Activity;
import android.app.AlarmManager;
import android.content.Context;
import android.Manifest;
import android.content.pm.PackageManager;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.webkit.JavascriptInterface;

public class AndroidBridge {
    private final Activity activity;

    AndroidBridge(Activity activity) {
        this.activity = activity;
    }

    @JavascriptInterface
    public void syncTasks(String tasksJson, String settingsJson, String completedJson) {
        AlarmScheduler.saveData(activity, tasksJson, settingsJson, completedJson);
        AlarmScheduler.scheduleAll(activity, System.currentTimeMillis() + 1_000L);
    }

    @JavascriptInterface
    public void requestPermissions() {
        activity.runOnUiThread(() -> {
            if (Build.VERSION.SDK_INT >= 33 && activity.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                activity.requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1002);
            }
            if (Build.VERSION.SDK_INT >= 31) {
                AlarmManager alarmManager = (AlarmManager) activity.getSystemService(Context.ALARM_SERVICE);
                if (alarmManager != null && !alarmManager.canScheduleExactAlarms()) {
                    try {
                        Intent intent = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                                Uri.parse("package:" + activity.getPackageName()));
                        activity.startActivity(intent);
                    } catch (Exception ignored) {
                        activity.startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                Uri.parse("package:" + activity.getPackageName())));
                    }
                }
            }
        });
    }

    @JavascriptInterface
    public void testAlarm() {
        activity.runOnUiThread(() -> NotificationHelper.showTestNotification(activity));
    }

    @JavascriptInterface
    public boolean exactAlarmAllowed() {
        if (Build.VERSION.SDK_INT < 31) return true;
        AlarmManager alarmManager = (AlarmManager) activity.getSystemService(Context.ALARM_SERVICE);
        return alarmManager != null && alarmManager.canScheduleExactAlarms();
    }

    @JavascriptInterface
    public String platform() {
        return "android";
    }
}
