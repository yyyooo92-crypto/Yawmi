package com.yawmi.app;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.HashSet;
import java.util.Set;

public final class AlarmScheduler {
    static final String PREFS = "yawmi_native";
    static final String KEY_TASKS = "tasks_json";
    static final String KEY_SETTINGS = "settings_json";
    static final String KEY_COMPLETED = "completed_json";
    static final String KEY_CODES = "scheduled_codes";
    static final String ACTION_PREFIX = "com.yawmi.app.MAIN_ALARM.";

    private AlarmScheduler() {}

    public static void saveData(Context context, String tasksJson, String settingsJson, String completedJson) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString(KEY_TASKS, tasksJson == null ? "[]" : tasksJson)
                .putString(KEY_SETTINGS, settingsJson == null ? "{}" : settingsJson)
                .putString(KEY_COMPLETED, completedJson == null ? "{}" : completedJson)
                .apply();
    }

    public static void createNotificationChannels(Context context) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;

        createChannel(context, nm, "yawmi_bell_v1", "يومي - جرس", R.raw.bell, true);
        createChannel(context, nm, "yawmi_soft_v1", "يومي - هادئ", R.raw.soft, true);
        createChannel(context, nm, "yawmi_chime_v1", "يومي - نغمة", R.raw.chime, true);
        createChannel(context, nm, "yawmi_bell_novib_v1", "يومي - جرس بدون اهتزاز", R.raw.bell, false);
        createChannel(context, nm, "yawmi_soft_novib_v1", "يومي - هادئ بدون اهتزاز", R.raw.soft, false);
        createChannel(context, nm, "yawmi_chime_novib_v1", "يومي - نغمة بدون اهتزاز", R.raw.chime, false);
        createChannel(context, nm, "yawmi_silent_v1", "يومي - صامت", 0, false);
        createChannel(context, nm, "yawmi_silent_vib_v1", "يومي - اهتزاز فقط", 0, true);
    }

    private static void createChannel(Context context, NotificationManager nm, String id, String name, int soundRes, boolean vibrate) {
        NotificationChannel c = new NotificationChannel(id, name, NotificationManager.IMPORTANCE_HIGH);
        c.setDescription("تنبيهات مهام تطبيق يومي");
        c.enableVibration(vibrate);
        c.setVibrationPattern(vibrate ? new long[]{0, 350, 160, 350, 160, 550} : new long[]{0});
        if (soundRes != 0) {
            Uri sound = Uri.parse("android.resource://" + context.getPackageName() + "/" + soundRes);
            AudioAttributes attrs = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build();
            c.setSound(sound, attrs);
        } else {
            c.setSound(null, null);
        }
        nm.createNotificationChannel(c);
    }

    public static void scheduleAll(Context context, long fromMillis) {
        cancelMainAlarms(context);
        createNotificationChannels(context);

        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String raw = prefs.getString(KEY_TASKS, "[]");
        String completedRaw = prefs.getString(KEY_COMPLETED, "{}");
        Set<String> scheduledCodes = new HashSet<>();
        try {
            JSONArray tasks = new JSONArray(raw);
            JSONObject completed = new JSONObject(completedRaw);
            for (int i = 0; i < tasks.length(); i++) {
                JSONObject task = tasks.optJSONObject(i);
                if (task == null || !task.optBoolean("alarm", false)) continue;
                long at = nextAlertMillis(task, completed, fromMillis);
                if (at <= 0) continue;
                String id = task.optString("id", "task_" + i);
                int code = stableCode("main:" + id);
                scheduleBroadcast(context, task.toString(), at, code, ACTION_PREFIX + code, false);
                scheduledCodes.add(String.valueOf(code));
            }
        } catch (Exception ignored) {}
        prefs.edit().putStringSet(KEY_CODES, scheduledCodes).apply();
    }

    private static void cancelMainAlarms(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        Set<String> oldCodes = prefs.getStringSet(KEY_CODES, new HashSet<>());
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am != null) {
            for (String s : oldCodes) {
                try {
                    int code = Integer.parseInt(s);
                    Intent intent = new Intent(context, AlarmReceiver.class).setAction(ACTION_PREFIX + code);
                    PendingIntent pi = PendingIntent.getBroadcast(context, code, intent,
                            PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
                    if (pi != null) {
                        am.cancel(pi);
                        pi.cancel();
                    }
                } catch (Exception ignored) {}
            }
        }
        prefs.edit().remove(KEY_CODES).apply();
    }

    static void scheduleSnooze(Context context, String taskJson, long atMillis) {
        int code = stableCode("snooze:" + taskJson.hashCode() + ":" + atMillis);
        scheduleBroadcast(context, taskJson, atMillis, code, "com.yawmi.app.SNOOZE_ALARM." + code, true);
    }

    private static void scheduleBroadcast(Context context, String taskJson, long atMillis, int code, String action, boolean snooze) {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        Intent intent = new Intent(context, AlarmReceiver.class)
                .setAction(action)
                .putExtra("task_json", taskJson)
                .putExtra("is_snooze", snooze);
        PendingIntent pi = PendingIntent.getBroadcast(context, code, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMillis, pi);
        } else {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMillis, pi);
        }
    }

    static long nextAlertMillis(JSONObject task, JSONObject completed, long fromMillis) {
        try {
            ZoneId zone = ZoneId.systemDefault();
            ZonedDateTime from = ZonedDateTime.ofInstant(java.time.Instant.ofEpochMilli(fromMillis), zone);
            LocalTime time = LocalTime.parse(task.optString("time", "09:00"));
            int reminder = Math.max(0, task.optInt("reminder", 0));
            String repeat = task.optString("repeat", "daily");

            if ("once".equals(repeat)) {
                String dateRaw = task.optString("specificDate", task.optString("created", ""));
                if (dateRaw.isEmpty()) return -1;
                LocalDate onceDate = LocalDate.parse(dateRaw);
                if (isCompleted(completed, onceDate, task.optString("id", ""))) return -1;
                ZonedDateTime occurrence = ZonedDateTime.of(onceDate, time, zone);
                ZonedDateTime alert = occurrence.minusMinutes(reminder);
                return alert.toInstant().toEpochMilli() >= fromMillis ? alert.toInstant().toEpochMilli() : -1;
            }

            for (int offset = 0; offset <= 14; offset++) {
                LocalDate date = from.toLocalDate().plusDays(offset);
                if (!applies(task, date)) continue;
                if (isCompleted(completed, date, task.optString("id", ""))) continue;
                ZonedDateTime occurrence = ZonedDateTime.of(date, time, zone);
                ZonedDateTime alert = occurrence.minusMinutes(reminder);
                long millis = alert.toInstant().toEpochMilli();
                if (millis >= fromMillis) return millis;
            }
        } catch (Exception ignored) {}
        return -1;
    }

    private static boolean isCompleted(JSONObject completed, LocalDate date, String taskId) {
        if (completed == null || taskId == null || taskId.isEmpty()) return false;
        JSONObject day = completed.optJSONObject(date.toString());
        return day != null && day.optBoolean(taskId, false);
    }

    private static boolean applies(JSONObject task, LocalDate date) {
        String repeat = task.optString("repeat", "daily");
        int jsDay = jsDay(date.getDayOfWeek());
        switch (repeat) {
            case "daily": return true;
            case "weekdays": return jsDay >= 0 && jsDay <= 4;
            case "weekend": return jsDay == 5 || jsDay == 6;
            case "custom":
                JSONArray days = task.optJSONArray("days");
                if (days == null) return false;
                for (int i = 0; i < days.length(); i++) if (days.optInt(i, -1) == jsDay) return true;
                return false;
            default: return false;
        }
    }

    private static int jsDay(DayOfWeek day) {
        int v = day.getValue(); // Monday=1 ... Sunday=7
        return v == 7 ? 0 : v;
    }

    static int stableCode(String value) {
        int h = value.hashCode();
        if (h == Integer.MIN_VALUE) h = 0;
        return Math.abs(h);
    }
}
