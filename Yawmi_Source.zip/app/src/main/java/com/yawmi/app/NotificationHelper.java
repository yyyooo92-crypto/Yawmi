package com.yawmi.app;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import org.json.JSONObject;

public final class NotificationHelper {
    private NotificationHelper() {}

    static void showTaskNotification(Context context, String taskJson, boolean snooze) {
        try {
            JSONObject task = new JSONObject(taskJson);
            SharedPreferences prefs = context.getSharedPreferences(AlarmScheduler.PREFS, Context.MODE_PRIVATE);
            JSONObject settings = new JSONObject(prefs.getString(AlarmScheduler.KEY_SETTINGS, "{}"));
            boolean soundEnabled = settings.optBoolean("sound", true);
            boolean vibrationEnabled = settings.optBoolean("vibration", true);
            String sound = task.optString("sound", "bell");
            String channel = channelId(sound, soundEnabled, vibrationEnabled);

            String name = task.optString("name", "مهمة");
            String time = task.optString("time", "");
            int reminder = task.optInt("reminder", 0);
            String note = task.optString("note", "");
            String label = snooze ? "تذكير بعد الغفوة" : (reminder > 0 ? "تذكير قبل " + reminder + " دقيقة" : "حان وقت المهمة");
            String body = label + (time.isEmpty() ? "" : " • " + time) + (note.isEmpty() ? "" : " • " + note);

            Intent open = new Intent(context, MainActivity.class)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent openPi = PendingIntent.getActivity(context, AlarmScheduler.stableCode("open:" + task.optString("id", name)), open,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

            Intent snoozeIntent = new Intent(context, SnoozeReceiver.class)
                    .setAction("com.yawmi.app.SNOOZE_ACTION." + task.optString("id", name))
                    .putExtra("task_json", taskJson);
            PendingIntent snoozePi = PendingIntent.getBroadcast(context, AlarmScheduler.stableCode("action:snooze:" + task.optString("id", name)), snoozeIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

            Notification notification = new Notification.Builder(context, channel)
                    .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                    .setContentTitle("يومي • " + name)
                    .setContentText(body)
                    .setStyle(new Notification.BigTextStyle().bigText(body))
                    .setContentIntent(openPi)
                    .setAutoCancel(true)
                    .setCategory(Notification.CATEGORY_ALARM)
                    .setVisibility(Notification.VISIBILITY_PUBLIC)
                    .setPriority(Notification.PRIORITY_MAX)
                    .addAction(new Notification.Action.Builder(android.R.drawable.ic_lock_idle_alarm, "غفوة 5 دقائق", snoozePi).build())
                    .build();

            NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.notify(AlarmScheduler.stableCode("notification:" + task.optString("id", name)), notification);
        } catch (Exception ignored) {}
    }

    static void showTestNotification(Context context) {
        try {
            JSONObject test = new JSONObject();
            test.put("id", "native_test");
            test.put("name", "اختبار المنبّه");
            test.put("time", "الآن");
            test.put("reminder", 0);
            test.put("sound", "chime");
            test.put("note", "إذا سمعت الصوت وظهر الإشعار فالمنبّه جاهز");
            showTaskNotification(context, test.toString(), false);
        } catch (Exception ignored) {}
    }

    private static String channelId(String sound, boolean soundEnabled, boolean vibrationEnabled) {
        if (!soundEnabled) return vibrationEnabled ? "yawmi_silent_vib_v1" : "yawmi_silent_v1";
        String base;
        if ("soft".equals(sound)) base = "yawmi_soft";
        else if ("chime".equals(sound)) base = "yawmi_chime";
        else base = "yawmi_bell";
        return base + (vibrationEnabled ? "_v1" : "_novib_v1");
    }
}
